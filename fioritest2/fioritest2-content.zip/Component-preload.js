//@ui5-bundle ns/fioritest2/Component-preload.js
jQuery.sap.registerPreloadedModules({
"version":"2.0",
"modules":{
	"ns/fioritest2/Component.js":function(){sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","ns/fioritest2/model/models"],function(e,t,i){"use strict";return e.extend("ns.fioritest2.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});
},
	"ns/fioritest2/controller/View1.controller.js":function(){sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("ns.fioritest2.controller.View1",{onInit:function(){}})});
},
	"ns/fioritest2/i18n/i18n.properties":'title=Title\nappTitle=View1\nappDescription=App Description\n',
	"ns/fioritest2/manifest.json":'{"_version":"1.12.0","sap.app":{"id":"ns.fioritest2","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"1.0.0"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","ach":"ach","sourceTemplate":{"id":"html5moduletemplates.basicSAPUI5ApplicationProjectModule","version":"1.40.12"}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":false,"rootView":{"viewName":"ns.fioritest2.view.View1","type":"XML","async":true,"id":"View1"},"dependencies":{"minUI5Version":"1.60.1","libs":{"sap.ui.core":{},"sap.m":{},"sap.ui.layout":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"ns.fioritest2.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"ns.fioritest2.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteView1","pattern":"RouteView1","target":["TargetView1"]}],"targets":{"TargetView1":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"View1","viewName":"View1"}}}}}',
	"ns/fioritest2/model/models.js":function(){sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"ns/fioritest2/view/View1.view.xml":'<mvc:View xmlns:mvc="sap.ui.core.mvc" xmlns="sap.m" controllerName="ns.fioritest2.controller.View1" displayBlock="true"><Shell id="shell"><App id="app"><pages><Page id="page" title="{i18n>title}"><content><Button xmlns="sap.m" text="Hello HAE!!" id="button0"/></content></Page></pages></App></Shell></mvc:View>'
}});
